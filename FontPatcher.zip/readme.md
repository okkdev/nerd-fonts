
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit a654a00f8b7fa9be17f29a9e057142e2795ea66d
        Author: okkdev <okkdev@users.noreply.github.com>
        Date:   Fri Apr 5 17:53:19 2024 +0000
        
            [ci] Rebuild original-source font
