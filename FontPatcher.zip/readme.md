
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit d3e5cc4081e61120d94ce206d247e8f09e134823
        Author: okkdev <okkdev@users.noreply.github.com>
        Date:   Fri Apr 5 16:53:07 2024 +0000
        
            [ci] Rebuild original-source font
