
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit 7bf37463bc2ad12b99ec7f78ec749c7186e59088
        Author: okkdev <okkdev@users.noreply.github.com>
        Date:   Fri Apr 5 16:11:57 2024 +0000
        
            [ci] Rebuild original-source font
